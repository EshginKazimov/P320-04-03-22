﻿using P320Practise.Models;
using System.Collections.Generic;

namespace P320Practise.ViewModels
{
    public class HomeViewModel
    {
        public List<Category> Categories { get; set; }
    }
}
