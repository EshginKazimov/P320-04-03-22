﻿namespace P320FrontToBack.Areas.AdminPanel.Data
{
    public static class Constants
    {
        public static string ImageFolderPath = "";
    }
}
