﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using P320FrontToBack.Areas.AdminPanel.Data;
using P320Practise.Areas.AdminPanel.Data;
using P320Practise.DataAccessLayer;
using P320Practise.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P320Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class ProductController : Controller
    {
        private readonly AppDbContext _dbContext;

        public ProductController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _dbContext.Products
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .ToListAsync();

            return View(products);
        }

        public async Task<IActionResult> Create()
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .ToListAsync();
            var childCategories = parentCategories[0].Children.ToList();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = childCategories;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, int parentCategoryId, int? childCategoryId)
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .ToListAsync();
            var childCategories = parentCategories[0].Children.ToList();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = childCategories;

            //var a = parentCategories.SelectMany(x => x.Children);

            if (!ModelState.IsValid)
                return View();

            var isProductExist = await _dbContext.Products
                .AnyAsync(x => x.Name.ToLower() == product.Name.ToLower());
            if (isProductExist)
            {
                ModelState.AddModelError("Name", "Bu product artiq movcuddur.");
                return View();
            }

            //var parentCategory = await _dbContext.Categories
            //    .Where(x => x.IsDeleted == false && x.Id == parentCategoryId)
            //    .Include(x => x.Children.Where(y => y.IsDeleted == false))
            //    .FirstOrDefaultAsync();
            var parentCategory = parentCategories.FirstOrDefault(x => x.Id == parentCategoryId);
            if (parentCategory == null)
                return BadRequest();

            if (childCategoryId != null)
            {
                //var isExistChildCategory =
                //    parentCategory.Children.All(x => x.Id != childCategoryId);
                //if (isExistChildCategory)
                //    return BadRequest();
                var isExistChildCategory =
                    parentCategory.Children.Any(x => x.Id == childCategoryId);
                if (!isExistChildCategory)
                    return BadRequest();
            }

            if (product.Photos == null || product.Photos.Length == 0)
            {
                ModelState.AddModelError("Photos", "Shekil yukleyin.");
                return View();
            }

            var productImages = new List<ProductImage>();

            foreach (var photo in product.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("Photos", $"{photo.Name} Duzgun shekil formati sechin.");
                    return View();
                }

                if (!photo.IsAllowedSize(1))
                {
                    ModelState.AddModelError("Photos", $"{photo.Name} 1Mb-dan artiq ola bilmez.");
                    return View();
                }

                var fileName = await photo.GenerateFile(Constants.ImageFolderPath);

                var productImage = new ProductImage
                {
                    Name = fileName,
                    ProductId = product.Id
                };

                productImages.Add(productImage);
            }

            product.ProductImages = productImages;

            var productCategories = new List<ProductCategory>();

            var parentProductCategory = new ProductCategory
            {
                CategoryId = parentCategoryId,
                ProductId = product.Id
            };
            productCategories.Add(parentProductCategory);

            if (childCategoryId != null /*|| childCategoryId.HasValue*/)
            {
                //var a = childCategoryId.GetValueOrDefault();

                var childProductCategory = new ProductCategory
                {
                    //CategoryId = childCategoryId.Value,
                    CategoryId = (int)childCategoryId,
                    ProductId = product.Id
                };
                productCategories.Add(childProductCategory);
            }

            product.ProductCategories = productCategories;

            await _dbContext.Products.AddAsync(product);
            await _dbContext.SaveChangesAsync();

            return Content("Success");
        }

        public async Task<IActionResult> LoadChildren(int? parentCategoryId)
        {
            if (parentCategoryId == null)
                return BadRequest();

            var category = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain && x.Id == parentCategoryId)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .FirstOrDefaultAsync();
            if (category == null)
                return NotFound();

            return PartialView("_ProductChildCategoriesPartial", category.Children.ToList());
        }
    }
}
